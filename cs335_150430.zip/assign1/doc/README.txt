To run the code :
1. Go to src folder
2. type following command to run the code lexer.py:  
	python3 lexer.py ../tests/input1/if.cl --cfg=../tests/cfg1/color1 --output=web.html
	
	
